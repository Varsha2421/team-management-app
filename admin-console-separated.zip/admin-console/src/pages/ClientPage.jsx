import { useState } from 'react';
import { Briefcase, Target, AlertTriangle, Wallet, Download, Plus, Filter, MapPin, MoreVertical } from 'lucide-react';
import { C } from '../constants/theme';
import StatCard from '../components/StatCard';
import Badge from '../components/Badge';
import ProgressBar from '../components/ProgressBar';
import Pager from '../components/Pager';

export default function ClientPage({ notify, onNavigate }) {
  const stats = [
    { icon: Briefcase, label: 'TOTAL CLIENTS', value: '1,254', trend: '+8%' },
    { icon: Target, label: 'ACTIVE PROJECTS', value: '42', sub: 'Ongoing' },
    { icon: AlertTriangle, label: 'CRITICAL TASKS', value: '09', sub: 'Require Action' },
    { icon: Wallet, label: 'TOTAL REVENUE', value: '$4.2M', sub: 'Q3-24' },
  ];

  const allClients = [
    { initials: 'RI', name: 'Reliance Industries Ltd.', project: 'Digital Transformation', status: 'Active', type: 'green', lead: 'Sanya Malhotra', progress: 75, due: 'Oct 24, 2024' },
    { initials: 'TC', name: 'Tata Consultancy Services', project: 'Cloud Migration', status: 'On Hold', type: 'amber', lead: 'Amitabh S.', progress: 32, due: 'Nov 12, 2024' },
    { initials: 'HDFC', name: 'HDFC Bank Corp', project: 'Security Audit', status: 'Planning', type: 'blue', lead: 'Vikram Roy', progress: 10, due: 'Dec 05, 2024' },
    { initials: 'AD', name: 'Adani Group', project: 'Infrastructure Monitoring', status: 'Critical', type: 'red', lead: 'Rohan Gupta', progress: 92, due: 'Oct 18, 2024' },
  ];

  const statuses = ['All Statuses', 'Active', 'On Hold', 'Planning', 'Critical'];
  const [statusFilter, setStatusFilter] = useState('All Statuses');
  const [page, setPage] = useState(1);

  const filtered = statusFilter === 'All Statuses' ? allClients : allClients.filter((c) => c.status === statusFilter);

  function cycleStatus() {
    const idx = statuses.indexOf(statusFilter);
    setStatusFilter(statuses[(idx + 1) % statuses.length]);
    setPage(1);
  }

  const deadlines = [
    { title: 'Security Patch V2', tag: 'CRITICAL', type: 'red', client: 'HDFC Bank Corp', due: 'Due in 4 hours' },
    { title: 'UI Feedback Loop', tag: 'URGENT', type: 'amber', client: 'Reliance Industries', due: 'Due tomorrow' },
    { title: 'Quarterly Report', tag: 'ROUTINE', type: 'gray', client: 'Tata Consultancy', due: 'Due in 3 days' },
  ];

  return (
    <>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-stone-800">Client Management</h1>
          <p className="text-sm text-stone-400 mt-1">Oversee active contracts and manage tactical operations.</p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => notify('Client list exported')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-white hover:opacity-90" style={{ backgroundColor: C.dark }}>
            <Download size={14} /> Export List
          </button>
          <button onClick={() => onNavigate('task')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-stone-900 hover:opacity-90" style={{ backgroundColor: C.gold }}>
            <Plus size={14} /> Add New Task
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {stats.map((s, i) => <StatCard key={i} {...s} />)}
      </div>

      <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex gap-2">
            <button onClick={() => notify('Advanced filters coming soon')} className="flex items-center gap-1 px-4 py-1.5 rounded-lg text-sm font-medium text-stone-500 border hover:bg-stone-50" style={{ borderColor: C.border }}>
              <Filter size={14} /> Filters
            </button>
            <button onClick={cycleStatus} className="px-4 py-1.5 rounded-lg text-sm font-medium text-stone-500 border hover:bg-stone-50" style={{ borderColor: C.border }}>{statusFilter}</button>
          </div>
          <span className="text-sm text-stone-400">Showing {filtered.length} of 1,254 entries</span>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-stone-400 border-b" style={{ borderColor: C.border }}>
              <th className="pb-2 font-medium">CLIENT NAME</th>
              <th className="pb-2 font-medium">PROJECT STATUS</th>
              <th className="pb-2 font-medium">ASSIGNED LEAD</th>
              <th className="pb-2 font-medium">PROGRESS</th>
              <th className="pb-2 font-medium">DUE DATE</th>
              <th className="pb-2 font-medium text-right">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="py-8 text-center text-stone-400">No clients with this status.</td></tr>
            )}
            {filtered.map((c, i) => (
              <tr key={i} className="border-b last:border-0" style={{ borderColor: C.border }}>
                <td className="py-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg flex items-center justify-center font-semibold text-xs bg-stone-100 text-stone-600">{c.initials}</div>
                    <div>
                      <div className="font-medium text-stone-800">{c.name}</div>
                      <div className="text-xs text-stone-400">{c.project}</div>
                    </div>
                  </div>
                </td>
                <td><Badge type={c.type} dot>{c.status.toUpperCase()}</Badge></td>
                <td className="text-stone-600">{c.lead}</td>
                <td className="w-40">
                  <div className="flex items-center gap-2">
                    <ProgressBar value={c.progress} color={c.type === 'red' ? '#ef4444' : C.gold} />
                    <span className="text-xs text-stone-500 w-10">{c.progress}%</span>
                  </div>
                </td>
                <td className="text-stone-600">{c.due}</td>
                <td className="text-right text-stone-400">
                  <MoreVertical size={15} className="inline cursor-pointer hover:text-stone-700" onClick={() => notify(`More options for ${c.name}`)} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex items-center justify-between mt-4">
          <span className="text-xs text-stone-400">Showing {filtered.length} of 1,254</span>
          <Pager page={page} totalPages={3} onChange={setPage} />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-stone-800">Client Concentration Map</h3>
            <span className="text-xs text-stone-400 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full" style={{ backgroundColor: C.gold }} /> Managed Regions
            </span>
          </div>
          <div className="h-48 rounded-xl bg-stone-50 flex items-center justify-center border" style={{ borderColor: C.border }}>
            <MapPin size={28} className="text-stone-300" />
          </div>
        </div>
        <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <h3 className="font-semibold text-stone-800 mb-4">Upcoming Task Deadlines</h3>
          <div className="space-y-3">
            {deadlines.map((d, i) => (
              <div key={i} className="border-l-4 rounded-r-xl p-3 bg-stone-50 cursor-pointer hover:bg-stone-100" style={{ borderColor: d.type === 'red' ? '#ef4444' : d.type === 'amber' ? '#f59e0b' : '#d1cfc9' }} onClick={() => notify(`Opening "${d.title}"`)}>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-stone-800">{d.title}</span>
                  <Badge type={d.type}>{d.tag}</Badge>
                </div>
                <div className="text-xs text-stone-400 mt-1">{d.client}</div>
                <div className="text-xs text-stone-500 mt-1">{d.due}</div>
              </div>
            ))}
          </div>
          <button onClick={() => onNavigate('task')} className="w-full mt-4 text-sm font-medium py-2 rounded-lg hover:opacity-80" style={{ color: C.goldSoft, backgroundColor: '#fdf4e3' }}>View All Tasks</button>
        </div>
      </div>
    </>
  );
}
