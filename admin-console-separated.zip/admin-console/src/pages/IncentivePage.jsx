import { useState } from 'react';
import { Wallet, Target, Calendar, Download, Plus, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import { BarChart, Bar, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { C } from '../constants/theme';
import StatCard from '../components/StatCard';
import Avatar from '../components/Avatar';
import Badge from '../components/Badge';
import ProgressBar from '../components/ProgressBar';

export default function IncentivePage({ notify }) {
  const stats = [
    { icon: Wallet, label: 'TOTAL INCENTIVE POOL', value: '$142,500.00', trend: '+12.5%', sub: 'vs Last Month' },
    { icon: Target, label: 'PAYOUT READINESS', value: '88.4%', progress: 88 },
    { icon: Calendar, label: 'NEXT PAYOUT DATE', value: 'Oct 30, 2023', sub: '12 Days Remaining' },
  ];

  const monthly = [
    { month: 'May', value: 62 },
    { month: 'Jun', value: 70 },
    { month: 'Jul', value: 88 },
    { month: 'Aug', value: 65 },
    { month: 'Sep', value: 84 },
    { month: 'Oct', value: 50 },
  ];

  const allocation = [
    { name: 'Direct Sales', value: 55 },
    { name: 'Upsell Actions', value: 30 },
    { name: 'Retention Bonus', value: 15 },
  ];

  const leaderboard = [
    { rank: 1, initials: 'SJ', idx: 0, name: 'Sarah Jenkins', attainment: '112%', up: true, amount: '$12,450.00' },
    { rank: 2, initials: 'DC', idx: 1, name: 'David Chen', attainment: '105%', up: true, amount: '$10,800.00' },
    { rank: 3, initials: 'MT', idx: 2, name: 'Marcus Thorne', attainment: '98%', up: null, amount: '$9,200.00' },
  ];

  const [pending, setPending] = useState([
    { title: 'Direct Sales Commission - ID #8821', by: 'Emily Watson', amount: '$450.00' },
    { title: 'Upsell Multiplier - ID #8845', by: 'Jordan Lee', amount: '$1,200.00' },
    { title: 'Annual Retention - ID #8790', by: 'Sarah Jenkins', amount: '$3,500.00' },
  ]);

  function approve(item) {
    setPending((prev) => prev.filter((p) => p.title !== item.title));
    notify(`Approved ${item.amount} for ${item.by}`);
  }

  return (
    <>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-stone-800">Team Incentive Performance</h1>
          <p className="text-sm text-stone-400 mt-1">Real-time tracking of quarterly payouts and individual performance metrics.</p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => notify('Incentive report exported')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-white hover:opacity-90" style={{ backgroundColor: C.dark }}>
            <Download size={14} /> Export Report
          </button>
          <button onClick={() => notify('Opening manual adjustment panel')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-stone-900 hover:opacity-90" style={{ backgroundColor: C.gold }}>
            <Plus size={14} /> Manual Adjust
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {stats.map((s, i) => <StatCard key={i} {...s} />)}
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-stone-800">Monthly Incentive Distribution</h3>
            <span className="text-sm text-stone-400">Last 6 Months ▾</span>
          </div>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={monthly}>
                <CartesianGrid stroke="#f0eee9" vertical={false} />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: '#a8a29e' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: '#a8a29e' }} axisLine={false} tickLine={false} />
                <Tooltip />
                <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                  {monthly.map((m, i) => (
                    <Cell key={i} fill={i === monthly.length - 1 ? C.gold : '#3f3a35'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-2xl p-5 text-white" style={{ backgroundColor: C.dark }}>
          <h3 className="font-semibold mb-4" style={{ color: C.gold }}>Pool Allocation</h3>
          <div className="space-y-4">
            {allocation.map((a, i) => (
              <div key={i}>
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span>{a.name}</span>
                  <span className="font-semibold">{a.value}%</span>
                </div>
                <ProgressBar value={a.value} bg="bg-white/10" />
              </div>
            ))}
          </div>
          <div className="mt-5 text-xs text-stone-400 bg-white/5 rounded-lg p-3 flex gap-2">
            <Target size={14} className="mt-0.5 shrink-0" />
            Allocations are adjusted based on Q4 priority goals for retention.
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-stone-800">Team Incentive Leaderboard</h3>
            <button onClick={() => notify('Opening full rank list')} className="text-sm font-medium hover:underline" style={{ color: C.goldSoft }}>View Full Rank</button>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-stone-400 border-b" style={{ borderColor: C.border }}>
                <th className="pb-2 font-medium">RANK</th>
                <th className="pb-2 font-medium">MEMBER</th>
                <th className="pb-2 font-medium">ATTAINMENT</th>
                <th className="pb-2 font-medium text-right">ESTIMATED INCENTIVE</th>
              </tr>
            </thead>
            <tbody>
              {leaderboard.map((l, i) => (
                <tr key={i} className="border-b last:border-0" style={{ borderColor: C.border }}>
                  <td className="py-3">
                    <span
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${l.rank === 1 ? 'text-stone-900' : 'text-stone-500 bg-stone-100'}`}
                      style={l.rank === 1 ? { backgroundColor: C.gold } : {}}
                    >
                      {l.rank}
                    </span>
                  </td>
                  <td>
                    <div className="flex items-center gap-3">
                      <Avatar initials={l.initials} idx={l.idx} size="sm" />
                      <span className="font-medium text-stone-800">{l.name}</span>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-1 text-stone-600">
                      {l.attainment}
                      {l.up === true && <TrendingUp size={13} className="text-emerald-500" />}
                      {l.up === false && <TrendingDown size={13} className="text-red-500" />}
                      {l.up === null && <Minus size={13} className="text-stone-400" />}
                    </div>
                  </td>
                  <td className="text-right font-semibold text-stone-800">{l.amount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-stone-800">Pending Payout Validations</h3>
            <Badge type="red">{pending.length} Required</Badge>
          </div>
          <div className="space-y-3">
            {pending.length === 0 && <p className="text-sm text-stone-400 py-6 text-center">All claims are validated.</p>}
            {pending.map((p, i) => (
              <div key={i} className="border rounded-xl p-3" style={{ borderColor: C.border }}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium text-stone-800">{p.title}</span>
                  <span className="text-sm font-semibold" style={{ color: C.goldSoft }}>{p.amount}</span>
                </div>
                <div className="text-xs text-stone-400 mb-2">Claimed by: {p.by}</div>
                <div className="flex gap-2">
                  <button onClick={() => approve(p)} className="flex-1 text-xs font-semibold py-1.5 rounded-lg text-stone-900 hover:opacity-90" style={{ backgroundColor: C.gold }}>Approve</button>
                  <button onClick={() => notify(`Reviewing claim from ${p.by}`)} className="flex-1 text-xs font-medium py-1.5 rounded-lg border hover:bg-stone-50" style={{ borderColor: C.border }}>Review</button>
                </div>
              </div>
            ))}
          </div>
          <button onClick={() => notify('Showing all pending claims')} className="w-full mt-3 text-sm font-medium py-2 rounded-lg hover:opacity-80" style={{ color: C.goldSoft, backgroundColor: '#fdf4e3' }}>View All Pending Claims</button>
        </div>
      </div>
    </>
  );
}
