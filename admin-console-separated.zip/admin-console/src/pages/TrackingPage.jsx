import { useState } from 'react';
import { CheckCircle2, AlertTriangle, Target, TrendingUp, Download, RefreshCw, MapPin, ChevronRight } from 'lucide-react';
import { C } from '../constants/theme';
import StatCard from '../components/StatCard';
import Avatar from '../components/Avatar';
import Badge from '../components/Badge';
import Pager from '../components/Pager';

export default function TrackingPage({ notify }) {
  const stats = [
    { icon: CheckCircle2, label: 'CHECKED IN', value: '11/12' },
    { icon: AlertTriangle, label: 'LATE ARRIVAL', value: '02' },
    { icon: Target, label: 'ACTIVE ROUTES', value: '08' },
    { icon: TrendingUp, label: 'AVG PRODUCTIVITY', value: '94.2%' },
  ];

  const feed = [
    { initials: 'AS', idx: 0, name: 'Aditi Sharma', id: 'EMP-0921', checkin: '08:45 AM', note: 'On Time', checkout: '--:--', location: 'Cyber City, Hub 4', status: 'On Site', type: 'green' },
    { initials: 'RV', idx: 1, name: 'Rahul Verma', id: 'EMP-0882', checkin: '09:12 AM', note: 'Late (12m)', checkout: '--:--', location: 'En-route Sector 62', status: 'Transit', type: 'amber' },
    { initials: 'MP', idx: 2, name: 'Meera Patel', id: 'EMP-1104', checkin: '08:55 AM', note: 'On Time', checkout: '--:--', location: 'DLF Phase 2', status: 'On Site', type: 'green' },
    { initials: 'SK', idx: 3, name: 'Sanjay Kumar', id: 'EMP-0743', checkin: '--:--', note: '', checkout: '--:--', location: 'Residential Address', status: 'Offline', type: 'gray' },
  ];

  const [page, setPage] = useState(1);
  const [syncing, setSyncing] = useState(false);

  function handleSync() {
    setSyncing(true);
    setTimeout(() => { setSyncing(false); notify('Dashboard synced'); }, 1100);
  }

  return (
    <>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-stone-800">Real-time Employee Tracking</h1>
          <p className="text-sm text-stone-400 mt-1">Live operational status of 12 field executives across the city.</p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => notify('Activity log exported')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-white hover:opacity-90" style={{ backgroundColor: C.dark }}>
            <Download size={14} /> Export Log
          </button>
          <button onClick={handleSync} disabled={syncing} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-stone-900 hover:opacity-90 disabled:opacity-70" style={{ backgroundColor: C.gold }}>
            <RefreshCw size={14} className={syncing ? 'animate-spin' : ''} /> {syncing ? 'Syncing...' : 'Sync Dashboard'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {stats.map((s, i) => <StatCard key={i} {...s} />)}
      </div>

      <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-stone-800">Executive Status Feed</h3>
          <div className="flex gap-2">
            <Badge type="green" dot>8 Online</Badge>
            <Badge type="amber" dot>3 Offline</Badge>
          </div>
        </div>
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-stone-400 border-b" style={{ borderColor: C.border }}>
              <th className="pb-2 font-medium">EMPLOYEE</th>
              <th className="pb-2 font-medium">CHECK-IN</th>
              <th className="pb-2 font-medium">CHECK-OUT</th>
              <th className="pb-2 font-medium">LOCATION</th>
              <th className="pb-2 font-medium">STATUS</th>
              <th className="pb-2 font-medium text-right">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {feed.map((f, i) => (
              <tr key={i} className="border-b last:border-0" style={{ borderColor: C.border }}>
                <td className="py-3">
                  <div className="flex items-center gap-3">
                    <Avatar initials={f.initials} idx={f.idx} size="sm" />
                    <div>
                      <div className="font-medium text-stone-800">{f.name}</div>
                      <div className="text-xs text-stone-400">ID: {f.id}</div>
                    </div>
                  </div>
                </td>
                <td>
                  <div className="text-stone-700">{f.checkin}</div>
                  {f.note && <div className={`text-xs ${f.note.includes('Late') ? 'text-red-500' : 'text-emerald-500'}`}>{f.note}</div>}
                </td>
                <td className="text-stone-400">{f.checkout}</td>
                <td className="text-stone-600">
                  <div className="flex items-center gap-1.5"><MapPin size={13} className="text-stone-400" />{f.location}</div>
                </td>
                <td><Badge type={f.type} dot>{f.status.toUpperCase()}</Badge></td>
                <td className="text-right text-stone-400">
                  <ChevronRight size={15} className="inline cursor-pointer hover:text-stone-700" onClick={() => notify(`Opening live location for ${f.name}`)} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="flex items-center justify-between mt-4">
          <span className="text-xs text-stone-400">Showing 4 of 12 employees</span>
          <Pager page={page} totalPages={3} onChange={setPage} />
        </div>
      </div>
    </>
  );
}
