import { useState } from 'react';
import { Users, Target, Award, Calendar, Download, Plus, Filter, Crosshair, Eye, MoreVertical } from 'lucide-react';
import { C } from '../constants/theme';
import StatCard from '../components/StatCard';
import Avatar from '../components/Avatar';
import Badge from '../components/Badge';
import ProgressBar from '../components/ProgressBar';
import Pager from '../components/Pager';

export default function EmployeePage({ notify }) {
  const stats = [
    { icon: Users, label: 'TOTAL TEAM', value: '24', sub: '+2 this month' },
    { icon: Target, label: 'ON DUTY', value: '18', sub: '75% active now' },
    { icon: Award, label: 'AVG RATING', value: '4.8', sub: 'Across 124 tasks' },
    { icon: Calendar, label: 'PENDING LEAVE', value: '3', sub: 'Needs review' },
  ];

  const allMembers = [
    { initials: 'AS', idx: 0, name: 'Aditi Sharma', id: 'EMP-2024-001', role: 'Senior Field Agent', status: 'On Duty', type: 'green', perf: 94, task: 'Client Site A - Audit' },
    { initials: 'RV', idx: 1, name: 'Rohan Varma', id: 'EMP-2024-042', role: 'Logistics Lead', status: 'In Transit', type: 'blue', perf: 82, task: 'Warehouse Shift 2' },
    { initials: 'PS', idx: 2, name: 'Priya Singh', id: 'EMP-2023-115', role: 'Compliance Officer', status: 'Off Duty', type: 'gray', perf: 98, task: 'None' },
    { initials: 'VM', idx: 3, name: 'Vikram Malhotra', id: 'EMP-2024-088', role: 'Operations Jr.', status: 'Urgent Task', type: 'red', perf: 76, task: 'Incident Report #992' },
  ];

  const [tab, setTab] = useState('all');
  const [highPerfOnly, setHighPerfOnly] = useState(false);
  const [page, setPage] = useState(1);

  const filtered = allMembers.filter((m) => {
    const tabMatch = tab === 'all' || (tab === 'active' && m.status !== 'Off Duty') || (tab === 'inactive' && m.status === 'Off Duty');
    const perfMatch = !highPerfOnly || m.perf >= 90;
    return tabMatch && perfMatch;
  });

  const departments = [
    { name: 'Field', value: 42 },
    { name: 'Logistics', value: 28 },
    { name: 'Legal', value: 18 },
    { name: 'Admin', value: 12 },
  ];

  return (
    <>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-stone-800">Team Management</h1>
          <p className="text-sm text-stone-400 mt-1">Monitor, manage, and coordinate your active field team.</p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => notify('Team list exported')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-white hover:opacity-90" style={{ backgroundColor: C.dark }}>
            <Download size={14} /> Export List
          </button>
          <button onClick={() => notify('Opening onboarding form...')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-stone-900 hover:opacity-90" style={{ backgroundColor: C.gold }}>
            <Plus size={14} /> Onboard New
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {stats.map((s, i) => <StatCard key={i} {...s} />)}
      </div>

      <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex gap-2">
            {[['all', 'All Members'], ['active', 'Active'], ['inactive', 'Inactive']].map(([id, label]) => (
              <button
                key={id}
                onClick={() => { setTab(id); setPage(1); }}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium ${tab === id ? 'text-white' : 'text-stone-500 border hover:bg-stone-50'}`}
                style={tab === id ? { backgroundColor: C.dark } : { borderColor: C.border }}
              >
                {label}
              </button>
            ))}
            <button
              onClick={() => setHighPerfOnly((v) => !v)}
              className={`flex items-center gap-1 px-4 py-1.5 rounded-lg text-sm font-medium border ${highPerfOnly ? '' : 'text-stone-500 hover:bg-stone-50'}`}
              style={highPerfOnly ? { borderColor: C.gold, color: C.goldSoft, backgroundColor: '#fdf4e3' } : { borderColor: C.border }}
            >
              <Filter size={14} /> {highPerfOnly ? 'Filter: ≥90%' : 'Filter'}
            </button>
          </div>
          <div className="text-sm text-stone-400">Sort by: <span className="text-stone-700 font-medium">Performance (High to Low)</span></div>
        </div>

        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs text-stone-400 border-b" style={{ borderColor: C.border }}>
              <th className="pb-2 font-medium">MEMBER</th>
              <th className="pb-2 font-medium">ROLE</th>
              <th className="pb-2 font-medium">STATUS</th>
              <th className="pb-2 font-medium">PERFORMANCE</th>
              <th className="pb-2 font-medium">ACTIVE TASK</th>
              <th className="pb-2 font-medium text-right">ACTIONS</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="py-8 text-center text-stone-400">No team members match this filter.</td></tr>
            )}
            {filtered.map((m, i) => (
              <tr key={i} className="border-b last:border-0" style={{ borderColor: C.border }}>
                <td className="py-3">
                  <div className="flex items-center gap-3">
                    <Avatar initials={m.initials} idx={m.idx} />
                    <div>
                      <div className="font-medium text-stone-800">{m.name}</div>
                      <div className="text-xs text-stone-400">ID: {m.id}</div>
                    </div>
                  </div>
                </td>
                <td className="text-stone-600">{m.role}</td>
                <td><Badge type={m.type} dot>{m.status}</Badge></td>
                <td className="w-36">
                  <div className="flex items-center gap-2">
                    <ProgressBar value={m.perf} />
                    <span className="text-xs text-stone-500 w-9">{m.perf}%</span>
                  </div>
                </td>
                <td className="text-stone-600">{m.task}</td>
                <td className="text-right text-stone-400">
                  <div className="flex justify-end gap-3">
                    <Crosshair size={15} className="cursor-pointer hover:text-stone-700" onClick={() => notify(`Locating ${m.name} on map`)} />
                    <Eye size={15} className="cursor-pointer hover:text-stone-700" onClick={() => notify(`Viewing ${m.name}'s profile`)} />
                    <MoreVertical size={15} className="cursor-pointer hover:text-stone-700" onClick={() => notify(`More options for ${m.name}`)} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex items-center justify-between mt-4">
          <span className="text-xs text-stone-400">Showing {filtered.length} of 24 team members</span>
          <Pager page={page} totalPages={3} onChange={setPage} />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-stone-800">Department Distribution</h3>
            <button onClick={() => notify('Opening department breakdown')} className="text-sm font-medium hover:underline" style={{ color: C.goldSoft }}>Details</button>
          </div>
          <div className="flex items-end justify-around h-40 gap-6">
            {departments.map((d, i) => (
              <div key={i} className="flex flex-col items-center gap-2 flex-1">
                <div className="w-full rounded-t-lg" style={{ height: `${d.value * 2.4}px`, backgroundColor: i === 0 ? C.gold : '#e7e4dd' }} />
                <span className="text-xs text-stone-400 uppercase font-medium">{d.name}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-2xl p-5 text-white flex flex-col justify-between" style={{ backgroundColor: C.dark }}>
          <div>
            <h3 className="font-semibold mb-2">Internal Training</h3>
            <p className="text-sm text-stone-400">3 new compliance modules available for your team.</p>
          </div>
          <button onClick={() => notify('Training modules assigned to team')} className="mt-6 w-full py-2.5 rounded-lg font-semibold text-stone-900 hover:opacity-90" style={{ backgroundColor: C.gold }}>Assign Modules</button>
        </div>
      </div>
    </>
  );
}
