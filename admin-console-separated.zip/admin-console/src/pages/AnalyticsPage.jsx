import { useState } from 'react';
import { TrendingUp, Award, Clock, Download, RefreshCw, TrendingDown } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { C } from '../constants/theme';
import StatCard from '../components/StatCard';
import Avatar from '../components/Avatar';
import Badge from '../components/Badge';
import ProgressBar from '../components/ProgressBar';

export default function AnalyticsPage({ notify }) {
  const stats = [
    { icon: TrendingUp, label: 'EFFICIENCY INDEX', value: '94.2%', trend: '+2.4%', sub: 'vs last week' },
    { icon: Award, label: 'TEAM MILESTONES', value: '28/32', sub: 'Q3 Objectives Status' },
    { icon: Clock, label: 'AVG RESOLUTION TIME', value: '1.4h', trend: '-0.2h', sub: 'optimization needed' },
  ];

  const chartData = [
    { week: 'WK 01', flow: 62, target: 58 },
    { week: 'WK 02', flow: 65, target: 60 },
    { week: 'WK 03', flow: 78, target: 62 },
    { week: 'WK 04', flow: 64, target: 63 },
    { week: 'WK 05', flow: 85, target: 68 },
    { week: 'WK 06', flow: 80, target: 70 },
    { week: 'WK 07', flow: 88, target: 72 },
    { week: 'WK 08', flow: 96, target: 75 },
    { week: 'WK 09', flow: 94, target: 76 },
    { week: 'WK 10', flow: 97, target: 78 },
  ];

  const employees = [
    { initials: 'JD', idx: 0, name: 'Jane Doe', designation: 'Senior', tasks: 142, eff: '98%', up: true },
    { initials: 'RV', idx: 1, name: 'Rahul Verma', designation: 'Mid', tasks: 128, eff: '94%', up: true },
    { initials: 'AS', idx: 2, name: 'Aditi Sharma', designation: 'Senior', tasks: 121, eff: '92%', up: false },
  ];

  const domains = [
    { name: 'Software Development', value: 42 },
    { name: 'Marketing Strategy', value: 28 },
    { name: 'Operations', value: 18 },
    { name: 'Compliance', value: 12 },
  ];

  const [refreshing, setRefreshing] = useState(false);
  function handleUpdate() {
    setRefreshing(true);
    setTimeout(() => { setRefreshing(false); notify('Analytics data refreshed'); }, 1100);
  }

  return (
    <>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-stone-800">Team Analytics Overview</h1>
          <p className="text-sm text-stone-400 mt-1">Real-time productivity distribution and operational performance tracking.</p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => notify('Exporting PDF...')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-white hover:opacity-90" style={{ backgroundColor: C.dark }}>
            <Download size={14} /> Export PDF
          </button>
          <button onClick={handleUpdate} disabled={refreshing} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-stone-900 hover:opacity-90 disabled:opacity-70" style={{ backgroundColor: C.gold }}>
            <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} /> {refreshing ? 'Updating...' : 'Update Data'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        {stats.map((s, i) => <StatCard key={i} {...s} />)}
      </div>

      <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-stone-800">Performance Trends (Operational Flow vs. Target)</h3>
          <div className="flex items-center gap-4 text-xs text-stone-500">
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: C.gold }} />Operational Flow</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-sm bg-stone-300" />Target Baseline</span>
          </div>
        </div>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid stroke="#f0eee9" vertical={false} />
              <XAxis dataKey="week" tick={{ fontSize: 11, fill: '#a8a29e' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: '#a8a29e' }} axisLine={false} tickLine={false} />
              <Tooltip />
              <Line type="monotone" dataKey="flow" stroke={C.gold} strokeWidth={2.5} dot={false} />
              <Line type="monotone" dataKey="target" stroke="#d6d3ce" strokeWidth={2} strokeDasharray="4 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-stone-800">Top Performing Employees</h3>
            <button onClick={() => notify('Opening full leaderboard')} className="text-sm font-medium hover:underline" style={{ color: C.goldSoft }}>Full Leaderboard</button>
          </div>
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs text-stone-400 border-b" style={{ borderColor: C.border }}>
                <th className="pb-2 font-medium">EMPLOYEE</th>
                <th className="pb-2 font-medium">DESIGNATION</th>
                <th className="pb-2 font-medium">TASKS COMPLETED</th>
                <th className="pb-2 font-medium">EFFICIENCY</th>
                <th className="pb-2 font-medium text-right">TREND</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((e, i) => (
                <tr key={i} className="border-b last:border-0" style={{ borderColor: C.border }}>
                  <td className="py-3">
                    <div className="flex items-center gap-3">
                      <Avatar initials={e.initials} idx={e.idx} size="sm" />
                      <span className="font-medium text-stone-800">{e.name}</span>
                    </div>
                  </td>
                  <td className="text-stone-600">{e.designation}</td>
                  <td className="text-stone-600">{e.tasks}</td>
                  <td><Badge type="green">{e.eff}</Badge></td>
                  <td className="text-right">
                    {e.up ? <TrendingUp size={15} className="inline text-emerald-500" /> : <TrendingDown size={15} className="inline text-red-500" />}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <h3 className="font-semibold text-stone-800 mb-4">Task Domain Distribution</h3>
          <div className="space-y-4">
            {domains.map((d, i) => (
              <div key={i}>
                <div className="flex items-center justify-between text-sm mb-1.5">
                  <span className="text-stone-600">{d.name}</span>
                  <span className="font-semibold text-stone-800">{d.value}%</span>
                </div>
                <ProgressBar value={d.value} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
