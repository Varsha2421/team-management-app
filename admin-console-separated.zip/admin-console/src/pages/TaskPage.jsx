import { useState } from 'react';
import { ClipboardList, TrendingUp, CheckCircle2, AlertTriangle, Download, Plus, Users } from 'lucide-react';
import { C } from '../constants/theme';
import StatCard from '../components/StatCard';
import Avatar from '../components/Avatar';
import Badge from '../components/Badge';
import ProgressBar from '../components/ProgressBar';

export default function TaskPage({ notify }) {
  const [queue, setQueue] = useState([
    { title: 'Client Audit & Risk Assessment', client: 'Reliance Industries Ltd', created: 'Created 2h ago', priority: 'HIGH PRIORITY', type: 'red', est: 'Est. 8 Hours' },
    { title: 'Quarterly Tax Compliance Filing', client: 'TATA Group', created: 'Created 4h ago', priority: 'STANDARD', type: 'blue', est: 'Est. 4 Hours' },
    { title: 'Document Verification - New Onboarding', client: 'Adani Enterprises', created: 'Created 6h ago', priority: 'LOW PRIORITY', type: 'gray', est: 'Est. 2 Hours' },
  ]);

  function assignTask(title) {
    setQueue((prev) => prev.filter((q) => q.title !== title));
    notify(`Assigned: ${title}`);
  }

  const stats = [
    { icon: ClipboardList, label: 'UNASSIGNED TASKS', value: String(queue.length).padStart(2, '0'), sub: 'Unassigned Queue', trend: '+12%' },
    { icon: TrendingUp, label: 'IN PROGRESS', value: '142', sub: 'Current Load' },
    { icon: CheckCircle2, label: 'COMPLETED TODAY', value: '56', sub: 'Priority Sort • Target Met' },
    { icon: AlertTriangle, label: 'DELAYED DELIVERIES', value: '04', sub: 'Critical' },
  ];

  const availability = [
    { name: 'Rahul Verma', load: 85, color: '#ef4444' },
    { name: 'Sana K.', load: 20, color: '#10b981' },
    { name: 'David Chen', load: 45, color: '#f59e0b' },
  ];

  const liveActivity = [
    { text: 'Rahul Verma completed Audit Phase 1', time: 'Just now' },
    { text: 'Sana K. started Quarterly Filing', time: '15 mins ago' },
  ];

  return (
    <>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold text-stone-800">Task Management</h1>
          <p className="text-sm text-stone-400 mt-1">Assign workflows and monitor delivery efficiency across teams.</p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => notify('Progress report exported')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-white hover:opacity-90" style={{ backgroundColor: C.dark }}>
            <Download size={14} /> Export Progress
          </button>
          <button onClick={() => notify('Opening new task form...')} className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-semibold text-stone-900 hover:opacity-90" style={{ backgroundColor: C.gold }}>
            <Plus size={14} /> Create New Task
          </button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4">
        {stats.map((s, i) => <StatCard key={i} {...s} />)}
      </div>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-stone-800">Unassigned Queue</h3>
            <button onClick={() => notify('Sorted by priority')} className="text-sm font-medium hover:underline" style={{ color: C.goldSoft }}>Priority Sort</button>
          </div>
          <div className="space-y-3">
            {queue.length === 0 && <p className="text-sm text-stone-400 py-6 text-center">Queue is clear — every task has been assigned.</p>}
            {queue.map((q, i) => (
              <div key={i} className="flex items-center justify-between border rounded-xl p-4" style={{ borderColor: C.border }}>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-stone-100">
                    <ClipboardList size={16} className="text-stone-400" />
                  </div>
                  <div>
                    <div className="font-medium text-stone-800 text-sm">{q.title}</div>
                    <div className="text-xs text-stone-400">{q.client} • {q.created}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <Badge type={q.type}>{q.priority}</Badge>
                    <div className="text-xs text-stone-400 mt-1">{q.est}</div>
                  </div>
                  <button onClick={() => assignTask(q.title)} className="text-sm font-semibold px-4 py-2 rounded-lg border hover:bg-amber-50" style={{ borderColor: C.gold, color: C.goldSoft }}>Assign</button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-stone-800">Employee Availability</h3>
              <Users size={16} className="text-stone-400" />
            </div>
            <div className="space-y-4">
              {availability.map((a, i) => (
                <div key={i} className="border rounded-xl p-3 cursor-pointer hover:bg-stone-50" style={{ borderColor: C.border }} onClick={() => notify(`${a.name} — ${a.load}% current load`)}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Avatar initials={a.name.split(' ').map((n) => n[0]).join('')} idx={i} size="sm" />
                      <span className="text-sm font-medium text-stone-800">{a.name}</span>
                    </div>
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: a.color }} />
                  </div>
                  <div className="flex items-center gap-2">
                    <ProgressBar value={a.load} color={a.color} />
                    <span className="text-xs text-stone-500">{a.load}% Load</span>
                  </div>
                </div>
              ))}
            </div>
            <button onClick={() => notify('Showing all assignees')} className="w-full mt-4 text-sm font-medium py-2 rounded-lg hover:opacity-80" style={{ color: C.goldSoft, backgroundColor: '#fdf4e3' }}>View All Assignees</button>
          </div>

          <div className="bg-white rounded-2xl border p-5" style={{ borderColor: C.border }}>
            <h3 className="font-semibold text-stone-800 mb-4">Live Activity</h3>
            <div className="space-y-4">
              {liveActivity.map((a, i) => (
                <div key={i} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <span className="w-2 h-2 rounded-full mt-1.5" style={{ backgroundColor: C.gold }} />
                    {i < liveActivity.length - 1 && <span className="w-px flex-1 bg-stone-200 mt-1" />}
                  </div>
                  <div>
                    <div className="text-sm text-stone-700">{a.text}</div>
                    <div className="text-xs text-stone-400">{a.time}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
