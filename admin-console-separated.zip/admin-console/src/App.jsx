import { useState, useRef } from 'react';
import Layout from './components/Layout';
import Toast from './components/Toast';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import EmployeePage from './pages/EmployeePage';
import ClientPage from './pages/ClientPage';
import TaskPage from './pages/TaskPage';
import TrackingPage from './pages/TrackingPage';
import AnalyticsPage from './pages/AnalyticsPage';
import IncentivePage from './pages/IncentivePage';
import { SEARCH_PLACEHOLDERS } from './constants/theme';

export default function App() {
  const [page, setPage] = useState('login');
  const [toast, setToast] = useState(null);
  const timerRef = useRef(null);

  function notify(message) {
    setToast(message);
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => setToast(null), 2200);
  }

  if (page === 'login') {
    return <LoginPage onLogin={() => setPage('dashboard')} />;
  }

  const pages = {
    dashboard: <DashboardPage notify={notify} onNavigate={setPage} />,
    employee: <EmployeePage notify={notify} onNavigate={setPage} />,
    client: <ClientPage notify={notify} onNavigate={setPage} />,
    task: <TaskPage notify={notify} onNavigate={setPage} />,
    tracking: <TrackingPage notify={notify} onNavigate={setPage} />,
    analytics: <AnalyticsPage notify={notify} onNavigate={setPage} />,
    incentive: <IncentivePage notify={notify} onNavigate={setPage} />,
  };

  return (
    <>
      <Layout
        active={page}
        onChange={setPage}
        onLogout={() => setPage('login')}
        user="Alex Thompson"
        role="Team Lead"
        searchPlaceholder={SEARCH_PLACEHOLDERS[page]}
      >
        {pages[page]}
      </Layout>
      <Toast message={toast} />
    </>
  );
}
