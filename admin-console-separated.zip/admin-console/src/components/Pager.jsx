import { ChevronLeft, ChevronRight } from 'lucide-react';
import { C } from '../constants/theme';

export default function Pager({ page, totalPages, onChange }) {
  const pages = [];
  for (let i = 1; i <= totalPages; i++) pages.push(i);
  return (
    <div className="flex gap-1">
      <button
        onClick={() => onChange(Math.max(1, page - 1))}
        className="w-8 h-8 rounded-lg border flex items-center justify-center text-stone-400 hover:text-stone-700 disabled:opacity-40"
        style={{ borderColor: C.border }}
        disabled={page === 1}
      >
        <ChevronLeft size={14} />
      </button>
      {pages.map((p) => (
        <button
          key={p}
          onClick={() => onChange(p)}
          className={`w-8 h-8 rounded-lg text-sm font-semibold flex items-center justify-center ${p === page ? 'text-stone-900' : 'border text-stone-500 hover:bg-stone-50'}`}
          style={p === page ? { backgroundColor: C.gold } : { borderColor: C.border }}
        >
          {p}
        </button>
      ))}
      <button
        onClick={() => onChange(Math.min(totalPages, page + 1))}
        className="w-8 h-8 rounded-lg border flex items-center justify-center text-stone-400 hover:text-stone-700 disabled:opacity-40"
        style={{ borderColor: C.border }}
        disabled={page === totalPages}
      >
        <ChevronRight size={14} />
      </button>
    </div>
  );
}
