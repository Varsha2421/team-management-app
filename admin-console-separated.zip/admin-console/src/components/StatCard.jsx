import { TrendingUp, TrendingDown } from 'lucide-react';
import { C } from '../constants/theme';
import ProgressBar from './ProgressBar';

export default function StatCard({ icon: Icon, label, value, sub, trend, dark, progress }) {
  return (
    <div
      className={`rounded-2xl border p-4 flex flex-col gap-3 ${dark ? 'text-stone-100' : 'bg-white border-stone-200'}`}
      style={dark ? { backgroundColor: C.dark, borderColor: C.dark } : {}}
    >
      <div className="flex items-center justify-between">
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${dark ? 'bg-white/10' : 'bg-stone-100'}`}>
          <Icon size={16} className={dark ? 'text-amber-300' : 'text-stone-500'} />
        </div>
        {trend && (
          <span className={`text-xs font-semibold flex items-center gap-1 ${trend.startsWith('+') ? 'text-emerald-600' : 'text-red-500'}`}>
            {trend.startsWith('+') ? <TrendingUp size={12} /> : <TrendingDown size={12} />}
            {trend}
          </span>
        )}
      </div>
      <div>
        <div className="text-xs font-medium tracking-wide uppercase text-stone-400">{label}</div>
        <div className="text-2xl font-bold mt-1">{value}</div>
        {sub && <div className="text-xs mt-1 text-stone-400">{sub}</div>}
      </div>
      {progress != null && <ProgressBar value={progress} />}
    </div>
  );
}
