import { Settings, LogOut, LayoutGrid, Users, Briefcase, ClipboardList, MapPin, BarChart3, Award } from 'lucide-react';
import { C } from '../constants/theme';

const NAV_ICONS = { LayoutGrid, Users, Briefcase, ClipboardList, MapPin, BarChart3, Award };

const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutGrid },
  { id: 'employee', label: 'Employee', icon: Users },
  { id: 'client', label: 'Client', icon: Briefcase },
  { id: 'task', label: 'Task assigning', icon: ClipboardList },
  { id: 'tracking', label: 'Employee tracking', icon: MapPin },
  { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  { id: 'incentive', label: 'Incentive', icon: Award },
];

export default function Sidebar({ active, onChange, onLogout }) {
  return (
    <aside className="w-64 shrink-0 min-h-screen flex flex-col" style={{ backgroundColor: C.sidebar }}>
      <div className="px-6 py-6">
        <div className="text-lg font-bold tracking-wide" style={{ color: C.gold }}>Admin Console</div>
        <div className="text-[11px] text-stone-500 tracking-widest mt-0.5">TEAM LEAD PORTAL</div>
      </div>
      <nav className="flex-1 px-3 space-y-1">
        {NAV.map((item) => {
          const isActive = active === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onChange(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors ${isActive ? 'font-medium' : 'text-stone-400 hover:text-stone-200 hover:bg-white/5'}`}
              style={isActive ? { backgroundColor: 'rgba(219,162,58,0.12)', color: C.gold, borderLeft: `3px solid ${C.gold}`, paddingLeft: '9px' } : {}}
            >
              <item.icon size={17} />
              {item.label}
            </button>
          );
        })}
      </nav>
      <div className="px-3 py-4 border-t" style={{ borderColor: C.sidebarBorder }}>
        <button className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-stone-400 hover:text-stone-200 hover:bg-white/5">
          <Settings size={17} /> Settings
        </button>
        <button onClick={onLogout} className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-red-400 hover:bg-white/5">
          <LogOut size={17} /> Logout
        </button>
      </div>
    </aside>
  );
}
