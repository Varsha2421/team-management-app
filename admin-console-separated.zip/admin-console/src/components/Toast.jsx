import { CheckCircle2 } from 'lucide-react';
import { C } from '../constants/theme';

export default function Toast({ message }) {
  if (!message) return null;
  return (
    <div className="fixed bottom-6 right-6 z-50">
      <div className="flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg text-sm font-medium text-white" style={{ backgroundColor: C.dark }}>
        <CheckCircle2 size={16} className="text-emerald-400 shrink-0" />
        {message}
      </div>
    </div>
  );
}
