import { Search, Bell, HelpCircle, Grid3x3 } from 'lucide-react';
import { C } from '../constants/theme';
import Avatar from './Avatar';

export default function TopBar({ name, role, query, onQuery, placeholder }) {
  return (
    <div className="flex items-center justify-between gap-6 px-8 py-4 bg-white border-b" style={{ borderColor: C.border }}>
      <div className="relative w-full max-w-md">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" />
        <input
          value={query}
          onChange={(e) => onQuery(e.target.value)}
          className="w-full pl-9 pr-4 py-2 rounded-lg bg-stone-100 text-sm outline-none placeholder-stone-400 focus:ring-2 focus:ring-amber-300"
          placeholder={placeholder}
        />
      </div>
      <div className="flex items-center gap-4 shrink-0">
        <Bell size={18} className="text-stone-400 cursor-pointer hover:text-stone-600" />
        <HelpCircle size={18} className="text-stone-400 cursor-pointer hover:text-stone-600" />
        <Grid3x3 size={18} className="text-stone-400 cursor-pointer hover:text-stone-600" />
        <div className="w-px h-6 bg-stone-200" />
        <div className="text-right">
          <div className="text-sm font-semibold text-stone-800">{name}</div>
          <div className="text-xs text-stone-400">{role}</div>
        </div>
        <Avatar initials={name.split(' ').map((n) => n[0]).join('')} idx={0} />
      </div>
    </div>
  );
}
