import { C } from '../constants/theme';

export default function ProgressBar({ value, color = C.gold, bg = 'bg-stone-100' }) {
  return (
    <div className={`h-1.5 rounded-full ${bg} w-full overflow-hidden`}>
      <div className="h-full rounded-full transition-all duration-300" style={{ width: `${value}%`, backgroundColor: color }} />
    </div>
  );
}
