# Admin Console

A React admin dashboard for team lead management.

## Project Structure

```
src/
├── App.jsx                      # Root component & routing
├── constants/
│   └── theme.js                 # Design tokens, colors, nav config
├── components/
│   ├── Avatar.jsx               # User avatar with color variants
│   ├── Badge.jsx                # Status badge with dot indicator
│   ├── Layout.jsx               # Page shell (sidebar + topbar)
│   ├── Pager.jsx                # Pagination control
│   ├── ProgressBar.jsx          # Animated progress bar
│   ├── Sidebar.jsx              # Left navigation
│   ├── StatCard.jsx             # KPI metric card
│   ├── Toast.jsx                # Toast notification
│   └── TopBar.jsx               # Top header with search
└── pages/
    ├── LoginPage.jsx            # Login screen
    ├── DashboardPage.jsx        # Team overview
    ├── EmployeePage.jsx         # Team management
    ├── ClientPage.jsx           # Client management
    ├── TaskPage.jsx             # Task assignment
    ├── TrackingPage.jsx         # Real-time tracking
    ├── AnalyticsPage.jsx        # Performance analytics
    └── IncentivePage.jsx        # Incentive management
```

## Setup

```bash
npm install
npm run dev
```

## Dependencies

- React 18+
- lucide-react
- recharts
- Tailwind CSS
